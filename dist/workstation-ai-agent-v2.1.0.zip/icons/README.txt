Placeholder icons for Chrome Extension.
To create proper icons, use a design tool or online generator.

For now, we'll create simple colored squares with text.
