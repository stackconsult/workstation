# Workstation AI Agent API

This Chrome extension connects to the Workstation backend API.

## Backend Server
The backend server must be running for full functionality.

**Start backend:**
```bash
npm start
```

**Default URL:** http://localhost:3000

## API Endpoints

### Workflow Execution
- `POST /api/workflow/execute` - Execute workflow
- `GET /api/workflow/status/:id` - Get workflow status
- `GET /api/workflow/history` - Get workflow history

### Templates
- `GET /api/templates` - List all templates
- `GET /api/templates/:id` - Get specific template

### Health
- `GET /health` - Health check
- `GET /api/health` - API health check

## Authentication
The extension uses JWT authentication when configured.

Set `JWT_SECRET` in the backend `.env` file.
