# Workstation AI Agent - Enterprise Chrome Extension

## 🚀 Installation Guide

### Method 1: Load Unpacked Extension (Development)

1. **Extract this ZIP file** to a permanent location
2. **Open Chrome** and navigate to: `chrome://extensions/`
3. **Enable Developer Mode** (toggle in top-right corner)
4. Click **"Load unpacked"**
5. Select the extracted folder
6. Extension installed! ✅

### Method 2: Chrome Web Store (Production)

*Coming soon - This extension will be published to the Chrome Web Store*

## 🔧 Backend Server Setup

This extension requires the backend server to be running for full functionality.

### Start the Backend:

```bash
# Navigate to the backend directory
cd /path/to/workstation

# Install dependencies (first time only)
npm install

# Build the backend
npm run build

# Start the server
npm start
```

**Server will run on:** http://localhost:3000

### Configure Extension:

1. Click the extension icon
2. Go to **Settings** tab
3. Set **Backend URL** to: `http://localhost:3000`
4. Click **Save Settings**

## 📚 Features

### ✨ Browser Automation
- Record and replay browser interactions
- Visual workflow builder
- Multi-step automation sequences
- Playwright-powered execution

### 🤖 AI Agents
- 25+ pre-configured AI agents
- Intelligent task execution
- Self-healing workflows
- Context-aware automation

### 🔄 Real-time Sync
- MCP (Model Context Protocol) integration
- Live workflow updates
- Auto-reconnect capability
- Status monitoring

### 📊 Workflow Management
- Template library (20+ workflows)
- Execution history
- Result tracking
- Export capabilities

## 🎯 Quick Start

### Execute a Workflow:

1. Click extension icon
2. Enter workflow description:
   ```
   Search for 'AI automation' on Google and take a screenshot
   ```
3. Click **🚀 Execute Workflow**
4. Watch automation run in real-time!

### Use Templates:

1. Go to **Templates** tab
2. Choose from 20+ ready-made workflows:
   - Google Search
   - Form Filling
   - Data Extraction
   - Screenshot Capture
   - Multi-page Navigation
3. Click template to load
4. Execute immediately or customize

### Visual Builder:

1. Go to **Builder** tab
2. Click **🎨 Open Builder**
3. Drag-and-drop workflow nodes
4. Connect actions visually
5. Save and execute

## 🛡️ Security Features

- JWT authentication
- Rate limiting
- Input validation
- XSS protection
- CSP enforcement
- Secure error handling

## 🔍 Troubleshooting

### Extension not connecting to backend:

1. Verify backend is running: `http://localhost:3000/health`
2. Check extension Settings > Backend URL
3. Ensure no firewall blocking localhost
4. Check browser console for errors

### Workflows not executing:

1. Verify backend connection (green indicator)
2. Check workflow syntax
3. Review execution history for errors
4. Enable auto-retry in Settings

### Icons not displaying:

1. Reload extension: `chrome://extensions/` → Click reload
2. Clear browser cache
3. Reinstall extension

## 📖 Documentation

Full documentation available at:
- **API Reference:** `/api/README.md`
- **GitHub:** https://github.com/creditXcredit/workstation
- **Architecture:** See ARCHITECTURE.md in repository

## 🆘 Support

- **Issues:** https://github.com/creditXcredit/workstation/issues
- **Discussions:** https://github.com/creditXcredit/workstation/discussions

## 📄 License

ISC License - See LICENSE file

## 🏆 Credits

Built with:
- Playwright (browser automation)
- Express.js (backend API)
- TypeScript (type safety)
- React (UI components)
- MCP (AI integration)

---

**Version:** 2.1.0 Enterprise
**Built:** $(date)
**Platform:** Google Chrome Extension
